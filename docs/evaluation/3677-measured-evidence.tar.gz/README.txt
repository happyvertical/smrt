Frozen synthetic evaluation evidence, issue3677. No credentials, databases or rendered media included.
run/report.json is the exact runner result. run/prediction-*.json are all300 heldout predictions.
corpus/manifest.json binds all1500 source bytes/groups/labels; regenerate media using the repository evaluation generator and pinned toolchain.
run/heldout/* and run/feedback/* JSON retain raw model offers, identity mappings and owning review/effect provenance.
freeze/ holds exact clean execution receipts, profile, release and final accounting. Absolute paths in historical receipts identify the original environment; every critical JSON artifact is included here under relative paths.
ARTIFACTS.json hashes each payload. Reproduce scores with the repository frozen scoring.mjs, these predictions and manifest; no provider requests required.
